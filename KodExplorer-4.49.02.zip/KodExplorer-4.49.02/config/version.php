<?php
define('KOD_VERSION','4.49');
define('KOD_VERSION_BUILD','02');//time(),20220826